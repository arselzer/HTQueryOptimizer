drop table if exists c1a, c1b, c1c, c2a, c2b, c2c, c3a, c3b, c3c, c4a, c4b, c4c, c5a, c5b, c5c, c6a, c6b, c6c cascade;

create table c1a (x integer, y integer, z integer);
create table c1b (x integer, y integer, z integer);
create table c1c (x integer, y integer, z integer);
create table c2a (x integer, y integer, z integer);
create table c2b (x integer, y integer, z integer);
create table c2c (x integer, y integer, z integer);
create table c3a (x integer, y integer, z integer);
create table c3b (x integer, y integer, z integer);
create table c3c (x integer, y integer, z integer);
create table c4a (x integer, y integer, z integer);
create table c4b (x integer, y integer, z integer);
create table c4c (x integer, y integer, z integer);
create table c5a (x integer, y integer, z integer);
create table c5b (x integer, y integer, z integer);
create table c5c (x integer, y integer, z integer);
create table c6a (x integer, y integer, z integer);
create table c6b (x integer, y integer, z integer);
create table c6c (x integer, y integer, z integer);

--copy t1 from 't1.csv' with (format csv);
