#!/bin/bash

./dsqgen -directory query_templates -input query_templates/templates.lst -output_dir queries -scale 1 -verbose
