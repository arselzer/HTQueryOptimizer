select t1.a,t3.b
from t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t15, t16, t17, t18, t19, t20
where t1.a = t2.a
and t2.a = t3.a
and t3.a = t4.a
AND t4.a = t5.a
AND t5.a = t6.a
AND t7.a = t3.a
AND t8.a = t7.a
AND t9.a = t8.a
AND t10.a = t9.a
AND t11.a = t9.a
AND t12.a = t11.a
AND t13.a = t12.a
AND t14.a = t13.a
AND t15.a = t14.a
AND t16.a = t13.a
AND t17.a = t16.a
AND t18.a = t16.a
AND t19.a = t18.a
AND t20.a = t19.a
AND t20.a = t18.a;